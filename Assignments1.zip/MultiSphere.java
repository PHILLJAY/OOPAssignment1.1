public class MultiSphere {
    //this is a comment
    //    //this is the main method
    public static void main(String[] args) {
        //initializing 3 objects
        Sphere test1 = new Sphere(4.2);
        Sphere test2 = new Sphere(2);
        Sphere test3 = new Sphere(3.6);
        //printing out values
        System.out.println( "test1: " + test1 + "\ntest2: " + test2 + "\ntest3: " + test3 );
    }
}
